const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB connection
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/familyrsvp', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const voteSchema = new mongoose.Schema({
  name: { type: String, default: 'Anonymous' },
  choice: { type: String, enum: ['Yes', 'No'], required: true },
  createdAt: { type: Date, default: Date.now },
});

const Vote = mongoose.model('Vote', voteSchema);

// Routes
app.post('/api/vote', async (req, res) => {
  try {
    const { name, choice } = req.body;
    if (!choice) return res.json({ success: false, message: 'Choice is required' });

    const vote = new Vote({ name: name || 'Anonymous', choice });
    await vote.save();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

app.get('/api/results', async (req, res) => {
  try {
    const yes = await Vote.countDocuments({ choice: 'Yes' });
    const no = await Vote.countDocuments({ choice: 'No' });
    res.json({ Yes: yes, No: no });
  } catch (err) {
    res.status(500).json({ success: false });
  }
});

app.get('/api/votes', async (req, res) => {
  try {
    const votes = await Vote.find().sort({ createdAt: -1 });
    res.json(votes);
  } catch (err) {
    res.status(500).json({ success: false });
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));